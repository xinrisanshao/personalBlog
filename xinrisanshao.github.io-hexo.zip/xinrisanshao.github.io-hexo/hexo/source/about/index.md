---
title: about
date: 2017-08-01 10:21:04
type: about
---
## 王新日
---
Big big pig
QQ:415595161
以后再补充吧

我的歌单
(周杰伦的没版权啊，只能许嵩了)
<div id="music163player">
   <iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=450 src="//music.163.com/outchain/player?type=0&id=866649915&auto=0&height=430"></iframe>
</div>